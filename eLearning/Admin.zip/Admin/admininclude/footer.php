
<!-- jquery and boostrap javascript-->
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/popper.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<!-- font awesome js -->

<script type="text/javascript" src="../js/all.min.js"></script>
<!-- admin ajax call javascript -->
<script type="text/javascript" src="../js/adminajaxrequest.js"></script>
<!-- custom javascript -->
<script type="text/javascript" src="../js/custom.js"></script>


</body>

</html>